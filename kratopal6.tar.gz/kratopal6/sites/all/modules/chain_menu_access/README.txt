This module is an API module. It has no functionality on its own. 

Install it only if some other module requires it.
