Place here the Admin Icons to be displayed in the "admin" pannel.
Refer to admin_icons.css for icon file names.