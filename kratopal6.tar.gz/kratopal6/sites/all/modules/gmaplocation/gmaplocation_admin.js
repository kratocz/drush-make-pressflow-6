$(document).ready(function() {
  // DISABLED: When address changes, remove previous latitude and longitude.
  // TODO: Dynamically look up new coordinates when address changes.
  $("#edit-gmaplocation-address").bind('change', function() {
  // $('#edit-gmaplocation-lat').val("");
  // $('#edit-gmaplocation-lng').val("");
  });
});