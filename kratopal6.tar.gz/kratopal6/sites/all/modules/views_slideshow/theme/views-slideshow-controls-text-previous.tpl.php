<span <?php print drupal_attributes($attributes); ?>><a href="#"><?php print t('Previous'); ?></a></span>
