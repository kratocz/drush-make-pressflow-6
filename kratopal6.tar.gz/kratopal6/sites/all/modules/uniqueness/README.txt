
Uniqueness module provides a way to avoid duplicate content on your site by
informing a user about similar or related content during creation of a new post.


Installing uniqueness module:

  1) Place the entirety of this directory in sites/all/modules/uniqueness

  2) Navigate to administer >> build >> modules. Enable Uniqueness.

  3) Enable uniqueness for each content type for which you would like to provide
     the uniqueness search.


For further help go to administer >> help >> uniqueness.