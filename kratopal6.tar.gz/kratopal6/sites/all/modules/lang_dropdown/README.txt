
  ------------------------------------------------------------------------------------
                                      INSTALLATION
  ------------------------------------------------------------------------------------

  This module requires optional core modules: "Locale" and "Content translation".
  The module will populate a new block named "Language switcher dropdown" under "{host}/admin/build/block".
  
  Please see the below instructions to configure the block.

  ------------------------------------------------------------------------------------
                                      CONFIGURATION
  ------------------------------------------------------------------------------------

  1) Set the value of the "Language negotiation" field to "Path prefix only." or "Path prefix with language fallback." 
     or "Domain name only." at "{host}/admin/settings/language/configure".
     
  2) Enable the "Language switcher dropdown" block at "{host}/admin/build/block".
  
  3) Configure the "Language switcher dropdown" block settings as per your preference.
