<item>
  <?php print $row; ?>
</item>
